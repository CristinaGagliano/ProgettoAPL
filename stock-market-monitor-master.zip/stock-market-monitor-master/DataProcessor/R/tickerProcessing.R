library(optparse)
library(httr)
library(jsonlite)
library(BBmisc)

# Opts parser
option_list <- list(
  make_option(c("--pathGetPrices"), type = "character",
            help = "GET path to retrieve price information. Example: http://127.0.0.1:8000/ticker/prices"),
  make_option(c("--pathGetHistories"), type = "character",
            help = "GET path to retrieve the history's stock. Example: http://127.0.0.1:8000/ticker/history"),
  make_option(c("--pathPostHomeitem"), type = "character",
            help = "POST path to send the processing results. Example : http://127.0.0.1:8000/stocks/homeitems")
)
opt <- parse_args(OptionParser(option_list = option_list))

#' Get a dataframe with stock prices
#' 
#' @author giusybng <Giusy Agata Bongiovanni>
#' @param pathGetPrices a string that expresses the base URI to get the stocks' prices
#'
#' @return dataframe the dataframe of the response content
#' @export
#'
#' @examples
#' getDataFrameFun(pathGetPrices)
getDataFrameFun <- function(pathGetPrices) {
    res <- GET(pathGetPrices)
    return(fromJSON(rawToChar(res$content)))
}

#' Calculate risk factor of a stock
#' 
#' @author dariof995 <Dario Fugale>
#' @param dfrow of a dataframe whose rows contain the information of the stocks
#' @param pathGetHistory a string that expresses the base URI to get the histories
#'
#' @return riskFactor an integer variance value between 1 and 5
#' @export
#'
#' @examples
#' calculateRiskFactorFun(dataframe.row, pathGetHistory)
calculateRiskFactorFun <- function(dfrow, pathGetHistory) {
    # Construct the full URI for the endpoint to be able to get 
    # by concatenating the symbol name at the end of the URI
    fullPathGetHistory <- paste(pathGetHistory, dfrow[['symbol']], sep = "/")
    # Make the GET call and save the value of the 'x' 
    # field present in the response content in 'history'
    history <- getDataFrameFun(fullPathGetHistory)$history
    x <- history[[1]]
    # The value of the closing prices present within the 
    # field contained in 'x' are saved in 'y'
    y <- x$close
    # The prices on which the variance must be calculated are those relating 
    # to the last 30 days. So only the final part of the 'y' values ?? is considered
    prices <- tail(y, n = 30)
    # Calculation of the variance on the considered values
    variance <- var(prices)
    # A riskFactor value is returned based on the range 
    # in which the variance value is contained
    if (variance >= 0 & variance <= 1) {
        # riskFactor 1 (better, more stable)
        return(1)
    }
    if (variance > 1 & variance <= 5) {
        # riskFactor 2
        return(2)
    }
    if (variance > 5 & variance <= 10) {
        # riskFactor 3
        return(3)
    }
    if (variance > 10 & variance <= 50) {
        # riskFactor 4
        return(4)
    }
    if (variance > 50) {
        # riskFactor 5 (worst, more unstable)
        return(5)
    }
}

#' Populate dataframe with the percentage increase and riskFactor
#'
#' @author dariof995 <Dario Fugale>
#' @author giusybng <Giusy Agata Bongiovanni>
#' 
#' @param data a dataframe whose rows contain the information of the stocks
#' @param pathGetHistory a string that expresses the base URI to get the histories
#'
#' @return a dataframe in which columns containing the results of the percentage increase and the risk factor are added
#' @export
#'
#' @examples
#' stocksPercentageIncreaseFun(df, pathGetHistories)
stocksPercentageIncreaseFun <- function(data, pathGetHistory) {
    # The percentage increase is calculated and the 
    # result is added in the "percentage" field
    data$percentage <- (((data$currentValue / data$previousValue) * 100) - 100)
    # Initializes the column in which the risk factor will be calculated
    data$riskFactor <- 0
    # Apply the row - level risk factor calculation 
    # function and the result is entered in the new 'riskFactor' column
    data$riskFactor <- apply(data, 1, calculateRiskFactorFun, pathGetHistory)
    return(data)
}

#' Get the best and worst stocks
#'
#' @author giusybng <Giusy Agata Bongiovanni>
#' @param data a dataframe whose rows contain the information of the stocks
#'
#' @return a list containing the best/worst stocks values
#' @export
#'
#' @examples
#' bestAndWorstStockFun(data)
bestAndWorstStockFun <- function(data) {

    #creation of best and worst stock in data frame format
    best.stock <- data[data$percentage == max(data$percentage), c(1, 2, 3, 4, 5, 6)]
    worst.stock <- data[data$percentage == min(data$percentage), c(1, 2, 3, 4, 5, 6)]

    #conversion of data frames into lists for compatibility with the format that IRModule expects to receive
    best.stock.list <- list(symbol = best.stock$symbol, previousValue = best.stock$previousValue, currentValue = best.stock$currentValue, sector = best.stock$sector, percentage = best.stock$percentage, riskFactor = best.stock$riskFactor)
    worst.stock.list <- list(symbol = worst.stock$symbol, previousValue = worst.stock$previousValue, currentValue = worst.stock$currentValue, sector = best.stock$sector, percentage = worst.stock$percentage, riskFactor = worst.stock$riskFactor)

    return(list(best.stock.list, worst.stock.list))
}

#' Get the best and worst sectors
#'
#' @author giusybng <Giusy Agata Bongiovanni>
#' @param data a dataframe whose rows contain the information of the stocks
#'
#' @return a list containing the best/worst sectors values
#' @export
#'
#' @examples
#' bestAndWorstSectorFun(data)
bestAndWorstSectorFun <- function(data) {

    #calculation of the weighted average of the percentages of the symbols grouped by sector
    means <- sapply(split(data, data$sector), function(x) weighted.mean(x$percentage, w = x$previousValue))
    groupby.sector <- data.frame("sector" = names(means), "percentage" = means)

    #calculation of best and worst sector based on the percentage
    best.sector <- groupby.sector[groupby.sector$percentage == max(groupby.sector$percentage),]
    worst.sector <- groupby.sector[groupby.sector$percentage == min(groupby.sector$percentage),]

    #conversion of data frames into lists for compatibility with the format that IRModule expects to receive
    best.sector.list <- list(sectorName = best.sector$sector, percentage = best.sector$percentage)
    worst.sector.list <- list(sectorName = worst.sector$sector, percentage = worst.sector$percentage)

    return(list(best.sector.list, worst.sector.list))
}

#' Send processing results by POST method 
#'
#' @author giusybng <Giusy Agata Bongiovanni>
#' @param pathPostHomeitem a string representing the URI to send the processing results
#' @param data a list that contains the values ?? to be inserted in the body of the POST
#'
#' @return None
#' @export
#'
#' @examples
#' bestAndWorstSectorFun(data)
#' 
#' @seealso bestAndWorstSectorFun and bestAndWorstStockFun
sendByPostFun <- function(pathPostHomeitem, data) {
    POST(pathPostHomeitem, body = data, encode = "json", verbose())
}

#' Get the best/worst stocks/sectors
#'
#' @author giusybng <Giusy Agata Bongiovanni>
#' @param data a dataframe whose rows contain the information of the stocks
#'
#' @return a list containing the best/worst stocks/sectors values
#' @export
#'
#' @examples
#' stocks <- bestAndWorstStockFun(data)
#' sectors <- bestAndWorstSectorFun(data)
getBestsWorstFun <- function(data) {
    stocks <- bestAndWorstStockFun(data)
    sectors <- bestAndWorstSectorFun(data)

    return(c(stocks = stocks, sectors = sectors))
}

mainFun <- function(pathGetPrices, pathGetHistories, pathPostHomeitem) {
    #GET from IRModule
    df <- getDataFrameFun(pathGetPrices)

    #calculation of the percentage increase in stocks
    data <- stocksPercentageIncreaseFun(df, pathGetHistories)

    data.list <- convertRowsToList(data, name.list = TRUE, name.vector = TRUE)

    #calculation of best and worst stock/sector
    stocks <- bestAndWorstStockFun(data)
    sectors <- bestAndWorstSectorFun(data)

    #POST to IRModule
    bodyPost = list(bestStock = stocks[[1]], worstStock = stocks[[2]], bestSector = sectors[[1]], worstSector = sectors[[2]], stocks = unname(data.list))
    sendByPostFun(pathPostHomeitem, bodyPost)
}

if (!interactive()) {
    mainFun(opt$pathGetPrices, opt$pathGetHistories, opt$pathPostHomeitem)
}