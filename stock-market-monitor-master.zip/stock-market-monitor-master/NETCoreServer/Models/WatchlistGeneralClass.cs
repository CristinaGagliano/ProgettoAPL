using Newtonsoft.Json;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>WatchlistGeneralClass</c> class.
    /// <remarks>
    /// Support class for serializing sector name within a watchlist item
    /// </remarks>
    /// </summary>   
    public class WatchlistGeneralClass : HomeItemStockFieldClass
    {
        [JsonProperty("sector")]
        public string sector { get; set; }

    }
}
