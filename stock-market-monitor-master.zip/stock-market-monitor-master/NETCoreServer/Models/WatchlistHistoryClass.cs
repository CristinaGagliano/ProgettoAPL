using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>WatchlistHistoryClass</c> class.
    /// <remarks>
    /// Support class for serializing of a Watchlist history item
    /// </remarks>
    /// </summary>    
    public class WatchlistHistoryClass
    {
        [JsonProperty("date")]
        public DateTime date { get; set; }

        [JsonProperty("price")]
        public float price { get; set; }
    }
}
