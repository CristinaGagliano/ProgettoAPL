using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>SectorModel</c> class.
    /// <remarks>
    /// Support class for serializing the information to be contained in the recommendations page
    /// </remarks>
    /// </summary>    
    public class SectorModel
    {
        /// <summary>
        /// A list of SelectListItems
        /// </summary>
        public List<SelectListItem> sectors { get; set; }

        /// <summary>
        /// A string representing the name of sector
        /// </summary>
        [JsonProperty("sectorName")]
        public string sectorName { get; set; }

        /// <summary>
        /// An integer number from 1 to 5 representing risk factor
        /// </summary>
        [JsonProperty("riskFactor")]
        public int riskFactor { get; set; }

                
    }
}
