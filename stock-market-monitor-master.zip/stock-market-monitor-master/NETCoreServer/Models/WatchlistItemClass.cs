using Newtonsoft.Json;
using System.Collections.Generic;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>WatchlistItemClass</c> class.
    /// <remarks>
    /// Support class for serializing of a Watchlist item
    /// </remarks>
    /// </summary>    
    public class WatchlistItemClass
    {
        [JsonProperty("general")]
        public WatchlistGeneralClass general { get; set; }

        [JsonProperty("history")]
        public List<WatchlistHistoryClass> history { get; set; }
    }
}
