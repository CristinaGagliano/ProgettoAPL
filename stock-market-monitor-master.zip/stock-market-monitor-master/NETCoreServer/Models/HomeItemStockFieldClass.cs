using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The main <c>HomeItemStockFieldClass</c> class. 
    /// Contains information relating to a sector field of a <c>HomeItemClass</c> object
    /// </summary>
    public class HomeItemStockFieldClass
    {
        /// <summary>
        /// A string representing the stock symbol
        /// </summary>
        [JsonProperty("symbol")]
        public string symbol { get; set; }

        /// <summary>
        /// A float number representing percentage increase/decrease of the stock
        /// </summary>
        [JsonProperty("percentage")]
        public float percentage { get; set; }

        /// <summary>
        /// A float number representing current value of the stock
        /// </summary>
        [JsonProperty("currentValue")]
        public float currentValue { get; set; }

        /// <summary>
        /// A float number representing previous value of the stock
        /// </summary>
        [JsonProperty("previousValue")]
        public float previousValue { get; set; }

        /// <summary>
        /// Constructor of <c>HomeItemStockFieldClass</c> with parameters
        /// </summary>
        /// <param name="symbol">Contains a string representing the stock symbol</param>
        /// <param name="percentage">Contains a float number representing percentage increase/decrease of the stock</param>
        /// <param name="currentValue">Contains a float number representing current value of the stock</param>
        /// <param name="previousValue">Contains a float number representing previous value of the stock</param>
        public HomeItemStockFieldClass(string symbol, float percentage, float currentValue, float previousValue)
        {
            this.symbol = symbol ?? throw new ArgumentNullException(nameof(symbol));
            this.percentage = percentage;
            this.currentValue = currentValue;
            this.previousValue = previousValue;
        }

        /// <summary>
        /// Empty Constructor of <c>HomeItemStockFieldClass</c>
        /// </summary>
        public HomeItemStockFieldClass()
        {
        }
    }
}
