using System;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The main <c>MongoConnectorClass</c> class.
    /// Contains all methods for performing mongodb database operations
    /// <list type="bullet">
    /// <item>
    /// <term>InsertDocumentAync</term>
    /// <description> Document insert</description>
    /// </item>
    /// <item>
    /// <term>CredentialsCheck</term>
    /// <description> User credential check</description>
    /// </item>
    /// <item>
    /// <term>UsernameCheck</term>
    /// <description> Username availability check</description>
    /// </item>
    /// <item>
    /// <term>FindByUsername</term>
    /// <description> Query by username</description>
    /// </item>
    /// <item>
    /// <term>UpdateUserCredentials</term>
    /// <description> Update the user's credentials</description>
    /// </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <para>This class acts as a connector to the MongoDB database deployed in an Atlas cluster.</para>
    /// <para>It allows you to carry out the operations necessary for managing data and users.</para>
    /// </remarks>
    public class MongoConnectorClass
    {
        public static string connectionString = "mongodb+srv://giusy_smm:9z9NcJT4iqJMEg6R@smmcluster.zi1gf.mongodb.net/users?retryWrites=true&w=majority";
        MongoClient mongoClient = new MongoClient(connectionString);
        public IMongoCollection<BsonDocument> collection { get; set; }

        /// <summary>
        /// Constructor of <c>MongoConnectorClass</c>
        /// </summary>
        public MongoConnectorClass()
        {
        }

        /// <summary>
        /// Asynchronous document insert
        /// </summary>
        /// <param name="doc">A BSON document which will need to be added</param>
        /// <param name="dbName">A string containing the database name</param>
        /// <param name="colName">A string containing collection name></param>
        /// <returns></returns>
        public async Task InsertDocumentAync(BsonDocument doc, string dbName, string colName)
        {
            var db = mongoClient.GetDatabase(dbName);
            var col = db.GetCollection<BsonDocument>(colName);
            await col.InsertOneAsync(doc);
        }

        /// <summary>
        /// User credential check
        /// </summary>
        /// <param name="username">Username string</param>
        /// <param name="password">Password string (hashed by sha256)</param>
        /// <param name="dbName">Database name string</param>
        /// <param name="colName">Collection name string</param>
        /// <returns>A boolean value</returns>
        public async Task<Boolean> CredentialsCheck(string username, string password, string dbName, string colName)
        {
            var db = mongoClient.GetDatabase(dbName);
            var col = db.GetCollection<BsonDocument>(colName);

            //Construct a filter using the Eq method
            //AND conjunction connects the clauses of a compound query
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.And(builder.Eq("username", username), builder.Eq("password", password));
            var result = await col.Find(filter).ToListAsync();

            if (result.Count != 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Check if a username is already stored in the database
        /// </summary>
        /// <param name="username">Username string</param>
        /// <param name="dbName">Database name string</param>
        /// <param name="colName">Collection name string</param>
        /// <returns>A boolean value</returns>
        public async Task<Boolean> UsernameCheck(string username, string dbName, string colName)
        {
            var db = mongoClient.GetDatabase(dbName);
            var col = db.GetCollection<BsonDocument>(colName);

            //Construct a filter using the Eq method
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("username", username);
            var result = await col.Find(filter).ToListAsync();
                         
            if (result.Count != 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Perform a query given the username
        /// </summary>
        /// <param name="username">Username string</param>
        /// <param name="dbName">Database name string</param>
        /// <param name="colName">Collection name string</param>
        /// <returns></returns>
        public async Task<UserSignupCredentialsClass> FindByUsername(string username, string dbName, string colName)
        {
            var db = mongoClient.GetDatabase(dbName);
            var col = db.GetCollection<BsonDocument>(colName);

            //Construct a filter using the Eq method
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("username", username);
            var result = await col.Find(filter).ToListAsync();
            if (result.Count != 0)
            {
                var x = result[0];
                var credentials = BsonSerializer.Deserialize<UserSignupCredentialsClass>(x);
                return credentials;
            }
            return null;
            
        }

        /// <summary>
        /// Update the user's credentials
        /// </summary>
        /// <param name="doc">A BSON document which will need to be added</param>
        /// <param name="username">Username string</param>
        /// <param name="dbName">Database name string</param>
        /// <param name="colName">Collection name string</param>
        /// <returns></returns>
        public async Task UpdateUserCredentials(BsonDocument doc, string username, string dbName, string colName)
        {
            var db = mongoClient.GetDatabase(dbName);
            var col = db.GetCollection<BsonDocument>(colName);

            //Construct a filter using the Eq method
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("username", username);
            
            await col.ReplaceOneAsync(filter, doc);
        }
    }
}
