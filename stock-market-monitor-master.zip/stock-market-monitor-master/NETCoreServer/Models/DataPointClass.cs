using System;
using System.Runtime.Serialization;

namespace NETCoreServer.Models
{
    //DataContract for Serializing Data - required to serve in JSON format
    //DataContract for Serializing Data - required to serve in JSON format
    /// <summary>
    /// The <c>DataPointClass</c> class.
    /// <remarks>
    /// Helpful class used for the json serialization of a DataPoint
    /// </remarks>
    /// </summary>    
    [DataContract]
    public class DataPointClass
    {
        /// <summary>
        /// Costructor <c>DataPointClass</c> with 2 parameters
        /// </summary>
        /// <param name="y">A double precision number</param>
        /// <param name="label">A string</param>
        public DataPointClass(double y, string label)
        {
            this.Y = y;
            this.Label = label;
        }

        /// <summary>
        /// Costructor <c>DataPointClass</c> with 1 parameters
        /// </summary>
        /// <param name="y">A double precision number</param>
        public DataPointClass(double y)
        {
            this.Y = y;
        }

        //Explicitly setting the name to be used while serializing to JSON. 
        [DataMember(Name = "label")]
        public string Label = null;

        //Explicitly setting the name to be used while serializing to JSON.
        [DataMember(Name = "y")]
        public Nullable<double> Y = null;
    }
}
