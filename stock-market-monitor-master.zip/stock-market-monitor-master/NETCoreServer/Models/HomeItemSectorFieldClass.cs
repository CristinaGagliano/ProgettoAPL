using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{

    /// <summary>
    /// The main <c>HomeItemSectorFieldClass</c> class. 
    /// Contains information relating to a sector field of a <c>HomeItemClass</c> object
    /// </summary>
    public class HomeItemSectorFieldClass
    {
        /// <summary>
        /// A string representing the name of sector
        /// </summary>
        [JsonProperty("sectorName")]
        public string sectorName { get; set; }

        /// <summary>
        /// Percentage increase/decrease
        /// </summary>
        [JsonProperty("percentage")]
        public float percentage { get; set; }

        /// <summary>
        /// Constructor of <c>HomeItemSectorFieldClass</c> with parameters
        /// </summary>
        /// <param name="sectorName"></param>
        /// <param name="percentage"></param>
        public HomeItemSectorFieldClass(string sectorName, float percentage)
        {
            this.sectorName = sectorName ?? throw new ArgumentNullException(nameof(sectorName));
            this.percentage = percentage;
        }

        /// <summary>
        /// Empty Constructor of <c>HomeItemSectorFieldClass</c>
        /// </summary>
        public HomeItemSectorFieldClass()
        {
        }
    }
}
