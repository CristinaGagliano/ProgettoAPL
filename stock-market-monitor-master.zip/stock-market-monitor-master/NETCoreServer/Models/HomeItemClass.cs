using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{

    /// <summary>
    /// The main <c>HomeItemClass</c> class.
    /// Contains information relating to the worst/best sectors/stocks
    /// </summary>
    public class HomeItemClass
    {
        /// <summary>
        /// Document identifier
        /// </summary>
        [JsonIgnore]
        [JsonProperty("id")]
        public int id { get; set; }

        /// <summary>
        ///  Best stock information 
        /// </summary>
        [JsonProperty("bestStock")]
        public HomeItemStockFieldClass bestStock { get; set; }

        /// <summary>
        ///  Worst stock information 
        /// </summary>
        [JsonProperty("worstStock")]
        public HomeItemStockFieldClass worstStock { get; set; }

        /// <summary>
        ///  Best sector information 
        /// </summary>
        [JsonProperty("bestSector")]
        public HomeItemSectorFieldClass bestSector { get; set; }

        /// <summary>
        ///  Worst stock information 
        /// </summary>
        [JsonProperty("worstSector")]
        public HomeItemSectorFieldClass worstSector { get; set; }

        /// <summary>
        /// Constructor of <c>HomeItemClass</c> with parameters
        /// </summary>
        /// <param name="id">Document identifier</param>
        /// <param name="bestStock">Contains information on the best stock of the day</param>
        /// <param name="worstStock">Contains information on the worst stock of the day</param>
        /// <param name="bestSector">Contains information on the best sector of the day</param>
        /// <param name="worstSector">Contains information on the worst sector of the day</param>
        public HomeItemClass(int id, HomeItemStockFieldClass bestStock, HomeItemStockFieldClass worstStock, HomeItemSectorFieldClass bestSector, HomeItemSectorFieldClass worstSector)
        {
            this.id = id;
            this.bestStock = bestStock ?? throw new ArgumentNullException(nameof(bestStock));
            this.worstStock = worstStock ?? throw new ArgumentNullException(nameof(worstStock));
            this.bestSector = bestSector ?? throw new ArgumentNullException(nameof(bestSector));
            this.worstSector = worstSector ?? throw new ArgumentNullException(nameof(worstSector));
        }

        /// <summary>
        /// Empty Constructor of <c>HomeItemClass</c>
        /// </summary>
        public HomeItemClass()
        {
        }
    }
}
