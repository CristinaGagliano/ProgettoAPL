using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>UserSignupCredentialsClass</c> class.
    /// <remarks>
    /// Support class for serializing the information from sign-up form
    /// </remarks>
    /// </summary>    
    [BsonIgnoreExtraElements]
    public class UserSignupCredentialsClass
    {

        /// <summary>
        /// Empty constructor of <c>UserSignupCredentialsClass</c>
        /// </summary>
        public UserSignupCredentialsClass()
        {
        }

        /// <summary>
        /// Constructor of <c>UserSignupCredentialsClass</c>
        /// </summary>
        /// <param name="firstName">A string representing the first name of user</param>
        /// <param name="lastName">A string representing the last name of user</param>
        /// <param name="email">A string representing user e-mail address</param>
        /// <param name="usernameSignup">Username string</param>
        /// <param name="passwordSignup">Password string (SHA 256)</param>
        public UserSignupCredentialsClass(string firstName, string lastName, string email, string usernameSignup, string passwordSignup)
        {
            this.firstName = firstName ?? throw new ArgumentNullException(nameof(firstName));
            this.lastName = lastName ?? throw new ArgumentNullException(nameof(lastName));
            this.email = email ?? throw new ArgumentNullException(nameof(email));
            this.usernameSignup = usernameSignup ?? throw new ArgumentNullException(nameof(usernameSignup));
            this.passwordSignup = passwordSignup ?? throw new ArgumentNullException(nameof(passwordSignup));
        }

        /// <summary>
        /// Document ObjectID 
        /// </summary>
        [BsonId]
        [BsonIgnore]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }

        /// <summary>
        /// First Name 
        /// </summary>
        [BsonElement("firstName")]
        [JsonProperty("firstName")]
        public string firstName { get; set; }

        /// <summary>
        /// Last Name 
        /// </summary>
        [BsonElement("lastName")]
        [JsonProperty("lastName")]
        public string lastName { get; set; }

        /// <summary>
        /// E-mail  
        /// </summary>
        [BsonElement("email")]
        [JsonProperty("email")]
        public string email { get; set; }

        /// <summary>
        /// Username  
        /// </summary>
        [BsonElement("username")]
        [JsonProperty("username")]
        public string usernameSignup { get; set; }
 
        /// <summary>
        /// Password  
        /// </summary>
        [BsonElement("password")]
        [JsonProperty("password")]
        public string passwordSignup { get; set; }
        
    }
}
