using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;

namespace NETCoreServer.Models
{
    /// <summary>
    /// The <c>UserSigninCredentialsClass</c> class.
    /// <remarks>
    /// Support class for serializing the information from sign-in form
    /// </remarks>
    /// </summary>    
    [BsonIgnoreExtraElements]
    public class UserSigninCredentialsClass
    {
        /// <summary>
        /// Empty constructor of <c>UserSigninCredentialsClass</c>
        /// </summary>
        public UserSigninCredentialsClass()
        {
        }

        /// <summary>
        /// Constructor of <c>UserSigninCredentialsClass</c>
        /// </summary>
        /// <param name="usernameSignin">A string representing the username used within sign-in form</param>
        /// <param name="passwordSignin">A string representing the password used within sign-in form</param>
        public UserSigninCredentialsClass(string usernameSignin, string passwordSignin)
        {
            this.usernameSignin = usernameSignin ?? throw new ArgumentNullException(nameof(usernameSignin));
            this.passwordSignin = passwordSignin ?? throw new ArgumentNullException(nameof(passwordSignin));
        }

        /// <summary>
        /// Document ObjectID 
        /// </summary>
        [BsonId]
        [BsonIgnore]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }

        /// <summary>
        /// Username
        /// </summary>
        [BsonElement("username")]
        [JsonProperty("username")]
        public string usernameSignin { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        [BsonElement("password")]
        [JsonProperty("password")]
        public string passwordSignin { get; set; }
    }    
}
