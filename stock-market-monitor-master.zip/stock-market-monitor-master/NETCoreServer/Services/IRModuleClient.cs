using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace NETCoreServer.Services
{
    /// <summary>
    /// The main <c>IRModuleClient</c> class.
    /// Contains the methods for communicating through REST API with the service offered by IRModule
    /// <list type="bullet">
    /// <item>
    /// <term>GetRequestAsync</term>
    /// <description> Send a GET request to the specified Uri as an asynchronous operation</description>
    /// </item>
    /// <item>
    /// <term>PostRequestAsync</term>
    /// <description> Send a POST request to the specified Uri as an asynchronous operation</description>
    /// </item>
    /// </list>
    /// </summary>
    public class IRModuleClient
    {
        /// <summary>
        /// IP address of IRModule host, tipically 'localhost'
        /// </summary>
        public string host { get; set; }
        /// <summary>
        /// Port number to communicate with IRModule
        /// </summary>
        public int port { get; set; }
        /// <summary>
        /// A string representing the URI to the endpoint
        /// </summary>
        public string endpoint { get; set; }

        /// <summary>
        /// Client Http
        /// </summary>
        public HttpClient client;

        /// <summary>
        /// Send a GET request to the specified Uri as an asynchronous operation
        /// </summary>
        /// <exceptions>
        /// Throws an exception if the HttpResponseMessage.IsSuccessCode property for the HTTP response is false
        /// </exceptions>
        /// <returns>return an HttpResponseMessage</returns>
        public async Task<HttpResponseMessage> GetRequestAsync()
        {
            /* Set the base address of the Uniform Resource Identifier (Uri) of the Internet resource used when sending the GET request
             * Add the specified header and its value into the HttpHeaders collection
             * Get the value of the Accept header for a GET Request
             * Send a GET request to the specified Uri as an asynchronous operation and return an HttpResponseMessage
             * Throws an exception if the HttpResponseMessage.IsSuccessCode property for the HTTP response is false
             */

            client.BaseAddress = new Uri("http://" + host + ":" + port.ToString());
            client.DefaultRequestHeaders.Add("User-Agent", "Anything");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            
            HttpResponseMessage response = await client.GetAsync(endpoint);
            response.EnsureSuccessStatusCode();

            return response;
        }

        /// <summary>
        /// Send a POST request to the specified Uri as an asynchronous operation
        /// </summary>
        /// <exceptions>
        /// Throws an exception if the HttpResponseMessage.IsSuccessCode property for the HTTP response is false
        /// </exceptions>
        /// <returns>return an HttpResponseMessage</returns>
        public async Task<HttpResponseMessage> PostRequestAsync(StringContent content)
        {
            /* Set the base address of the Uniform Resource Identifier (Uri) of the Internet resource used when sending the POST request
             * Add the specified header and its value into the HttpHeaders collection
             * Get the value of the Accept header for a GET Request
             * Send a POST request to the specified Uri as an asynchronous operation and return an HttpResponseMessage
             * Throws an exception if the HttpResponseMessage.IsSuccessCode property for the HTTP response is false
             */

            client.BaseAddress = new Uri("http://" + host + ":" + port.ToString());
            client.DefaultRequestHeaders.Add("User-Agent", "Anything");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.PostAsync(endpoint, content);
            response.EnsureSuccessStatusCode();

            return response;
            
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        /// <summary>
        /// Constructor of <c>IRModuleClient</c>
        /// </summary>
        /// <param name="host">A string representing IP address of IRModule host, tipically 'localhost'</param>
        /// <param name="port">An integer number representing the port to communicate with IRModule</param>
        /// <param name="endpoint">A string representing the URI to the endpoint</param>
        public IRModuleClient(string host, int port, string endpoint)
        {
            this.host = host ?? throw new ArgumentNullException(nameof(host));
            this.port = port;
            this.endpoint = endpoint ?? throw new ArgumentNullException(nameof(endpoint));
            client = new HttpClient();
        }
    }
}
