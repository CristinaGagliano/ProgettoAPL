using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NETCoreServer.Models;
using NETCoreServer.Services;
using Newtonsoft.Json;

namespace NETCoreServer.Controllers
{
    /// <summary>
    /// The main <c>WatchlistController</c> class.
    /// Implement controller methods for the "Watchlist" page
    /// <list type="bullet">
    /// <item>
    /// <term>Index</term>
    /// <description> Controller for the Index page</description>
    /// </item>
    /// <item>
    /// <term>SetDataPoints</term>
    /// <description> Create DataPointClass lists to pass to view</description>
    /// </item>
    /// </list>
    /// </summary>
    
    public class WatchlistController : Controller
    {
        /// <summary>
        /// Controller for the Index page
        /// </summary>
        /// <returns>View with WatchlistItemClass list</returns>
        public async Task<IActionResult> Index()
        {
            /* Create an IRModuleClient and pass host, port, endpoint and username
             * Receive an HttpResponseMessage calling irmClient.GetRequestAsync()
             * Get response content that is List<WatchlistItemClass> wList
             * Call CreateDataPoint passing it wList if wList != null
             * If wList == null, the user will be redirect to EmptyWatchlist page
             */

            string username = HttpContext.Session.GetString("UserID");
            IRModuleClient irmClient = new IRModuleClient(host: "127.0.0.1", port: 8000, endpoint: "watchlist/" + username);          
                     
            HttpResponseMessage response = await irmClient.GetRequestAsync();
            List<WatchlistItemClass> wList = await response.Content.ReadAsAsync<List<WatchlistItemClass>>();

            if(wList == null)
            {
               return View("EmptyWatchlist");
            }
            
            SetDataPoints(wList);

            return View(wList);
        }


        /// <summary>
        /// Create DataPointClass lists
        /// </summary>
        private void SetDataPoints(List<WatchlistItemClass> wList)
        {
            /* Create a list of DataPointClass for totalDataPoints in wich pass y = currentValue and label = symbol
             * Create a list of DataPointClass for historyDataPoints in wich pass y = price and label = date
             */

            List<DataPointClass> totalDataPoints = new List<DataPointClass>();
            List<DataPointClass> historyDataPoints = new List<DataPointClass>();
            foreach (WatchlistItemClass w in wList)
            {
                totalDataPoints.Add(new DataPointClass(w.general.currentValue, w.general.symbol));

                foreach (WatchlistHistoryClass h in w.history)
                {
                    historyDataPoints.Add(new DataPointClass(h.price, h.date.ToString("MMMM dd, yyyy")));
                }

                ViewData[w.general.symbol] = JsonConvert.SerializeObject(historyDataPoints);
                historyDataPoints = new List<DataPointClass>();
            }
            ViewBag.Total = JsonConvert.SerializeObject(totalDataPoints);
        }
    }
}
