using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using NETCoreServer.Models;
using NETCoreServer.Security;

namespace NETCoreServer.Controllers
{
    /// <summary>
    /// The main <c>SignController</c> class.
    /// Implement controller methods for the "SignIn/SignOut" pages
    /// <list type="bullet">
    /// <item>
    /// <term>Signin</term>
    /// <description> Controller for the SignIn page</description>
    /// </item>
    /// <item>
    /// <term>Signup</term>
    /// <description> Controller for the SignOut page</description>
    /// </item>
    /// </list>
    /// </summary>
    
    public class SignController : Controller
    {
        /// <summary>
        /// Controller for the Signin page
        /// </summary>
        /// <returns>View</returns>
        public ActionResult Signin()
        {
            return View();
        }


        /// <summary>
        /// Controller for the Signup page
        /// </summary>
        /// <returns>View</returns>
        public ActionResult Signup()
        {
            return View();
        }


        /// <summary>
        /// Controller for the Signup page 
        /// </summary>
        /// <returns>View</returns>
        [HttpPost]
        public async Task<ActionResult> Signup(UserSignupCredentialsClass credentials)
        {
            /* Check if the user has entered all fields
             */

            UserSignupCredentialsClass userCredentials;
            MongoConnectorClass mongoConnector = new MongoConnectorClass();

            if (credentials.usernameSignup != null & credentials.passwordSignup != null & credentials.firstName != null & credentials.lastName != null & credentials.email != null)
            {
                /* The user has entered all fields
                 * Password encrypt to check database match
                 * Username uniqueness verification
                 */

                string encryptedPassword = HashGeneratorClass.Encrypt(credentials.passwordSignup);
                
                userCredentials = new UserSignupCredentialsClass(credentials.firstName, credentials.lastName, credentials.email, credentials.usernameSignup, encryptedPassword);
                bool result = await mongoConnector.UsernameCheck(userCredentials.usernameSignup, "users", "user-credentials");
                if (result)
                {
                    /* The username is not avilable
                     * A message will be shown in the View to warn the user
                     */

                    ViewData["Error"] = "Username not available, choose another one.";
                    return View();
                }
                else
                {
                    /* The username is avilable
                     * The user is registered in the db and redirect to Home
                     */

                    await mongoConnector.InsertDocumentAync(userCredentials.ToBsonDocument(), "users", "user-credentials");
                    HttpContext.Session.SetString("UserID", credentials.usernameSignup);
                    return RedirectToAction("Index", "Home");
                }
            }

            /* The user has entered all fields
             * A message will be shown in the View to warn the user
             */

            ViewData["Error"] = "Please, enter all fields.";
            return View();
        }


        /// <summary>
        /// Controller for the Signin page 
        /// </summary>
        /// <returns>View</returns>
        [HttpPost]
        public async Task<ActionResult> Signin(UserSigninCredentialsClass credentials)
        {
            MongoConnectorClass mongoConnector = new MongoConnectorClass();

            if (credentials.usernameSignin != null & credentials.passwordSignin != null)
            {
                /* Password encrypt to check database match
                 * Encrypt because it is impossible decrypt the result of a One Way Hash like SHA256
                 * Username and password checking
                 */
                string encryptedPassword = HashGeneratorClass.Encrypt(credentials.passwordSignin);
                
                bool result = await mongoConnector.CredentialsCheck(credentials.usernameSignin, encryptedPassword, "users", "user-credentials");
                if (result)
                {
                    /* The credentials are correct
                     * The user is redirect to Home
                     */
                    HttpContext.Session.SetString("UserID", credentials.usernameSignin);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    /* The credentials are not correct
                     * A message will be shown in the View to warn the user
                     */
                    ViewData["Error"] = "Please, enter correct credentials.";
                    return View();
                }
            }
            /* The user has not entered all the fields
             * A message will be shown in the View to warn the user
             */
            ViewData["Error"] = "Please, enter all fields.";
            return View();
        }
    }
}
