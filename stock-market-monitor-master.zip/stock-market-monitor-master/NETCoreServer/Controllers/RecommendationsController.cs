using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using NETCoreServer.Models;
using NETCoreServer.Services;
using Newtonsoft.Json;

namespace NETCoreServer.Controllers
{
    /// <summary>
    /// The main <c>RecommendationsController</c> class.
    /// Implement controller methods for the "Recommendations" page
    /// <list type="bullet">
    /// <item>
    /// <term>Index</term>
    /// <description> Controller for the Index page</description>
    /// </item>
    /// <item>
    /// <term>PopulateSectors</term>
    /// <description> To get the sectors list</description>
    /// </item>
    /// </list>
    /// </summary>
    /// 
    public class RecommendationsController : Controller
    {

        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Index()
        {
            /* Create SectorModel sector and populate it through PopulateSectors()
             * It will be used to DropDownList in View
             */

            SectorModel sector = new SectorModel();
            sector.sectors = await PopulateSectors();

            return View(sector);            
        }


        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>View with new data</returns>
        [HttpPost]
        public async Task<ActionResult> Index(SectorModel sector)
        {
            /* Populate sector.sectors through PopulateSectors()
             * It will be passed to View()
             */

            sector.sectors = await PopulateSectors();                       
            
            if (sector.sectorName != null & Enumerable.Range(1, 5).Contains(sector.riskFactor))
            {
                /* The user has selected a sector and entered a risk factor between 1 and 5
                 * A POST Request is sent to the server, passing the sector and risk factor chosen by the user
                 * A ViewBag is set up to notify the user that the request has been sent successfully
                 */

                IRModuleClient irmClient = new IRModuleClient(host: "127.0.0.1", port: 8000, endpoint: "stocks/search");
                Dictionary<string, object> dic = new Dictionary<string, object> { { "username", HttpContext.Session.GetString("UserID") }, { "sector", sector.sectorName }, { "riskFactor", sector.riskFactor } };
                string json = JsonConvert.SerializeObject(dic);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                await irmClient.PostRequestAsync(content);
                
                ViewBag.Message = "Sector " + sector.sectorName + " entered correctly. Go to the Watchlist to see the stocks trend.";               
                
            }
            else
            {
                /* The user has not selected a sector and entered a risk factor between 1 and 5
                 * A ViewBag is set up to prompt the user to enter correct values
                 */

                ViewBag.Message = "Please, select the options correctly.";
            }
            
            
            return View(sector);
        }


        /// <summary>
        /// Get the sectors list
        /// </summary>
        /// <returns>List of SelectListItem</returns>
        private static async Task<List<SelectListItem>> PopulateSectors()
        {
            /* A GET Request is sent to the server to get the sectors list
             * The response content contains the list
             * It returns item which is a list of SelectListItem, which will be assigned to sector.sectors
             */

            List<SelectListItem> items = new List<SelectListItem>();

            IRModuleClient irmClient = new IRModuleClient(host: "127.0.0.1", port: 8000, endpoint: "sectors");
            HttpResponseMessage response = await irmClient.GetRequestAsync();
            List<string> sectorList = await response.Content.ReadAsAsync<List<string>>();           


            for (int i = 0; i < sectorList.Count(); i++)
            {
                items.Add(new SelectListItem
                {
                    Text = sectorList[i],
                    Value = sectorList[i]
                });
            }
            
            return items;
        }
    }
}
