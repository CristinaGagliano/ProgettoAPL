using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using NETCoreServer.Models;
using NETCoreServer.Security;
using System.Threading.Tasks;

namespace NETCoreServer.Controllers
{

    /// <summary>
    /// The main <c>PersonalDataController</c> class.
    /// Implement controller methods for the "Personal Informations" page
    /// <list type="bullet">
    /// <item>
    /// <term>Index</term>
    /// <description> Controller for the Index page</description>
    /// </item>
    /// <item>
    /// <term>SetViewDataCredentials</term>
    /// <description> To set updates on user data </description>
    /// </item>
    /// </list>
    /// </summary>
    
    public class PersonalDataController : Controller
    {

        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>View</returns>
        /// <returns></returns>
        public async Task<ActionResult> Index()
        {
            /* Get UserID by Session
             * Call mongoConnector.FindByUsername to retrieve complete information from the database to display in the View
             * Call SetViewDataCredentials to set value of each ViewData
             */

            UserSignupCredentialsClass userCredentials;
            string username = HttpContext.Session.GetString("UserID");
            MongoConnectorClass mongoConnector = new MongoConnectorClass();
            userCredentials = await mongoConnector.FindByUsername(username, "users", "user-credentials");
            
            SetViewDataCredentials(userCredentials);

            return View();
        }


        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>View</returns>
        [HttpPost]
        public async Task<ActionResult> Index(UserSignupCredentialsClass credentials)
        {
            /* Get UserID by Session
             * Verify that the user has not left empty fields 
             */

            UserSignupCredentialsClass userCredentials;
            string username = HttpContext.Session.GetString("UserID");
            MongoConnectorClass mongoConnector = new MongoConnectorClass();

            if (credentials.usernameSignup != null & credentials.passwordSignup != null & credentials.firstName != null & credentials.lastName != null & credentials.email != null)
            {
                /* The user has filled in all fields
                 * If the user has not changed the username, proceed with the update of the credentials in the db
                 * Else check that the new username chosen has not already been taken by another user
                 */

                if (username.Equals(credentials.usernameSignup))
                {
                    string encryptedPassword = HashGeneratorClass.Encrypt(credentials.passwordSignup);
                    userCredentials = new UserSignupCredentialsClass(credentials.firstName, credentials.lastName, credentials.email, credentials.usernameSignup, encryptedPassword);
                    await mongoConnector.UpdateUserCredentials(userCredentials.ToBsonDocument(), username, "users", "user-credentials");

                    return RedirectToAction("Index", "PersonalData");
                }
                else
                {
                    userCredentials = await mongoConnector.FindByUsername(credentials.usernameSignup, "users", "user-credentials");
                    if(userCredentials == null)
                    {
                        /* The username is available
                         * Encrypt the password
                         * Proceed with the update of the credentials in the db
                         */

                        string encryptedPassword = HashGeneratorClass.Encrypt(credentials.passwordSignup);
                        userCredentials = new UserSignupCredentialsClass(credentials.firstName, credentials.lastName, credentials.email, credentials.usernameSignup, encryptedPassword);
                        await mongoConnector.UpdateUserCredentials(userCredentials.ToBsonDocument(), username, "users", "user-credentials");
                        HttpContext.Session.SetString("UserID", userCredentials.usernameSignup);

                        return RedirectToAction("Index", "PersonalData");
                    }
                    else
                    {
                        /* The username is not available
                         * Reload the page keeping the values ​​just entered by the user
                         * Add in the View an error message to urge the user to choose a different username
                         */

                        ViewData["ErrorNewUsername"] = "Username not available, choose another one.";
                        SetViewDataCredentials(credentials);

                        return View();
                    }
                }
            }
            else
            {
                /* The user has not filled in all fields
                 * Reload the page keeping the values ​​just entered by the user
                 * Add in the View an error message to urge the user to choose a different username
                 */

                ViewData["ErrorNewUsername"] = "Please, enter all fields.";
                SetViewDataCredentials(credentials);

                return View();
            }
            

        }


        /// <summary>
        /// Set updates on user data
        /// </summary>
        private void SetViewDataCredentials(UserSignupCredentialsClass credentials)
        {
            /* Set ViewData values
             */
            ViewData["FirstName"] = credentials.firstName;
            ViewData["LastName"] = credentials.lastName;
            ViewData["Email"] = credentials.email;
            ViewData["Username"] = credentials.usernameSignup;
        }

    }
}
