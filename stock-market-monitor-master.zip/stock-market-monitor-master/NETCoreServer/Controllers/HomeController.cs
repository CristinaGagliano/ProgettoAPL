using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NETCoreServer.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using NETCoreServer.Services;

namespace NETCoreServer.Controllers
{
    /// <summary>
    /// The main <c>HomeController</c> class.
    /// Implement controller methods for the "home" page
    /// <list type="bullet">
    /// <item>
    /// <term>Index</term>
    /// <description> Controller for the Index page</description>
    /// </item>
    /// <item>
    /// <term>CreateDataPoint</term>
    /// <description> Useful method for populating charts</description>
    /// </item>
    /// <item>
    /// <term>About</term>
    /// <description> Controller for the About page</description>
    /// </item>
    /// <item>
    /// <term>Contact</term>
    /// <description> Controller for the Contact page</description>
    /// </item>
    /// <item>
    /// <term>LogOut</term>
    /// <description> Controller for the LogOut page</description>
    /// </item>
    /// <item>
    /// <term>Error</term>
    /// <description> Controller for the Error page</description>
    /// </item>
    /// </list>
    /// </summary>
    
    public class HomeController : Controller
    {
        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>View</returns>        
        public async Task<ActionResult> Index()
        {
            /* Create an IRModuleClient and pass host, port and endpoint
             * Receive an HttpResponseMessage calling irmClient.GetRequestAsync()
             * Get response content that is HomeItemClass homeItem
             * Call CreateDataPoint passing it homeItem
             */

            IRModuleClient irmClient = new IRModuleClient(host: "127.0.0.1", port: 8000, endpoint: "stocks/homeitems/today");
            HttpResponseMessage response = await irmClient.GetRequestAsync();
            HomeItemClass homeItem = await response.Content.ReadAsAsync<HomeItemClass>();
            
            CreateDataPoint(homeItem);

            return View();
        }


        /// <summary>
        /// Useful method for populating charts on Index page
        /// </summary>
        /// <param name="homeItem"> An HomeItemClass object</param>
        private void CreateDataPoint(HomeItemClass homeItem)
        {
            /* Create a list of DataPointClass for best and worst stock in wich pass y = value and label = day
             * Create a list of DataPointClass for best and worst sector in wich pass y = percentage
             * Insert the four lists, after having serialized them in Json, in separate ViewBags that will be used for plotting the charts in the View
             */

            List<DataPointClass> dataPointsBestStock = new List<DataPointClass>{
                new DataPointClass(homeItem.bestStock.previousValue, "Yesterday"),
                new DataPointClass(homeItem.bestStock.currentValue, "Today")

            };
            ViewBag.BestStockName = JsonConvert.SerializeObject(homeItem.bestStock.symbol);
            ViewBag.DataPointsBestStock = JsonConvert.SerializeObject(dataPointsBestStock);


            List<DataPointClass> dataPointsWorstStock = new List<DataPointClass>{
                new DataPointClass(homeItem.worstStock.previousValue, "Yesterday"),
                new DataPointClass(homeItem.worstStock.currentValue, "Today")

            };
            ViewBag.WorstStockName = JsonConvert.SerializeObject(homeItem.worstStock.symbol);
            ViewBag.DataPointsWorstStock = JsonConvert.SerializeObject(dataPointsWorstStock);


            List<DataPointClass> dataPointBestSector = new List<DataPointClass>{
                new DataPointClass(homeItem.bestSector.percentage, " ")
            };
            ViewBag.BestSectorName = JsonConvert.SerializeObject(homeItem.bestSector.sectorName);
            ViewBag.DataPointBestSector = JsonConvert.SerializeObject(dataPointBestSector);


            List<DataPointClass> dataPointWorstSector = new List<DataPointClass>{
                new DataPointClass(homeItem.worstSector.percentage, " ")
            };
            ViewBag.WorstSectorName = JsonConvert.SerializeObject(homeItem.worstSector.sectorName);
            ViewBag.DataPointWorstSector = JsonConvert.SerializeObject(dataPointWorstSector);
        }


        /// <summary>
        /// Controller for the About page
        /// </summary>
        /// <returns>View</returns>
        public IActionResult About()
        {
            return View();
        }


        /// <summary>
        /// Controller for the Contact page
        /// </summary>
        /// <returns>View</returns>
        public IActionResult Contact()
        {     
            return View();
        }


        /// <summary>
        /// Index view controller
        /// </summary>
        /// <returns>SignIn View</returns>
        public IActionResult LogOut()
        {
            /* Remove all entries from the current session
             * Redirect to SignIn
             */
            HttpContext.Session.Clear();

            return RedirectToAction("SignIn", "Sign");
        }


        /// <summary>
        /// Controller for the Error page
        /// </summary>
        /// <returns>View</returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
