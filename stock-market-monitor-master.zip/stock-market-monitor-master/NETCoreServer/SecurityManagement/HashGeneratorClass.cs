using System;
using System.Security.Cryptography;
using System.Text;

namespace NETCoreServer.Security
{
    /// <summary>
    /// The main <c>HashGeneratorClass</c> class.
    /// Contains encryption/hashing methods for security
    /// <list type="bullet">
    /// <item>
    /// <term>Encrypt</term>
    /// <description> Calculate the hash code from an input string by SHA 256</description>
    /// </item>
    /// </list>
    /// </summary>
    public class HashGeneratorClass
    {
        /// <summary>
        /// Calculate the hash code from an input string by SHA 256
        /// </summary>
        /// <param name="value">The string you want to hash. Typically it is a password</param>
        /// <returns>Return the hashcode of the string</returns>
        public static string Encrypt(string value)
        {            
            using (SHA256 mySHA256 = SHA256.Create())
            {
                UTF8Encoding utf8 = new UTF8Encoding();

                //ComputeHash computes the hash value for the specified byte array
                byte[] hashValue = mySHA256.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(hashValue);
            }
        }
       
    }
}
