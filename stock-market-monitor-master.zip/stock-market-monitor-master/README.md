# Stock Market Monitor
Software system for stock market monitoring and investment plan management.

## Versions
* R Version ==  3.5.2
* Python Version == 3.6.0
* .NET Core Version == 2.1

## Setup
1) Clone the project

2) Create new virtual enviroment python 

`cd IRModule`

`python -m venv envsmm`

`pip install -r requirements.txt`

3) Start IRModule (start Django Server)

`python manage.py runserver`

4) Run the stockrunner.py for the extraction

`python stockrunner.py runserver`

#### Note: 
Be sure to start the job based on the day of the week you are running the script. (line 44) 

0 - Monday

1 - Tuesday

2 - Wednesday

3 - Thursday

4 - Friday

5 - Saturday

6 - Sunday

5) Run NETCoreServer 

