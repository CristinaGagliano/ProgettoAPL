"""
Job scheduling script for updating IRModule values ​​in the database
"""
import os
import time 
import typing
import requests
from pytz import utc
from datetime import datetime
from shutil import copyfile

from apscheduler.schedulers.background import BackgroundScheduler

from stockapp.utils.csvutils import readcsv
from stockapp.services.processing.dataprocessorconnector import analyze_trends

HOST = "127.0.0.1"
PORT = 8000

TICKER_FILE = "../data/tickers.csv"
TEMP_TICKER_FILE = "../data/temp_tickers.csv"
LOG_REQUESTS_FILE = "../data/logs_requests.txt"

def do_extraction(csvfile:str = TEMP_TICKER_FILE, 
                  host:str = HOST, 
                  port:int = PORT, 
                  verbose:int = 1) -> None:
    tickers = readcsv(csvfile)
    if tickers and len(tickers) > 1: tickers = tickers[1:]
    for ticker in tickers:
        print(ticker)
        headers = {'Content-Type': 'application/json'}
        payload = "{\r\n    \"symbol\" : \""+ticker[0]+"\",\r\n    \"datasource\" : \"yahoofinance\"\r\n}"
        response = requests.request("POST", "http://"+HOST+":"+str(PORT)+"/ticker", headers=headers, data=payload)
        if verbose: 
            print(response.text)

    analyze_trends(host, port)

def _initialize(csvfile = TICKER_FILE, 
                csvtemp = TEMP_TICKER_FILE, 
                logfile = LOG_REQUESTS_FILE):
    if not os.path.exists(csvtemp): 
        copyfile(csvfile, csvtemp)

if __name__ == '__main__':
    _initialize()

    job_defaults = {
        'coalesce': False,
        'max_instances': 1
    }
    scheduler = BackgroundScheduler(job_defaults=job_defaults)
    '''
    year (int|str)  -  4-digit year
    month (int|str)  -  month (1-12)
    day (int|str)  -  day of the (1-31)
    week (int|str)  -  ISO week (1-53)
    day_of_week (int|str)  -  number or name of weekday (0-6 or mon,tue,wed,thu,fri,sat,sun)
    hour (int|str)  -  hour (0-23)
    minute (int|str)  -  minute (0-59)
    second (int|str)  -  second (0-59)
    
    start_date (datetime|str)  -  earliest possible date/time to trigger on (inclusive)
    end_date (datetime|str)  -  latest possible date/time to trigger on (inclusive)
    timezone (datetime.tzinfo|str)  -  time zone to use for the date/time calculations (defaults to scheduler timezone)
  
    *  any  Fire on every value
    */a  any  Fire every a values, starting from the minimum
    a-b  any  Fire on any value within the a-b range (a must be smaller than b)
    a-b/c  any  Fire every c values within the a-b range
    xth y  day  Fire on the x -th occurrence of weekday y within the month
    last x  day  Fire on the last occurrence of weekday x within the month
    last  day  Fire on the last day within the month
    x,y,z  any  Fire on any matching expression; can combine any number of any of the above expressions
    '''
    scheduler.add_job(do_extraction, 'cron', day_of_week=str(datetime.today().weekday()), second='*/10')
    scheduler.start()  # The scheduling task here is independent 1 A thread 
    print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))

    try:
        while True:
            time.sleep(1)  # Other tasks are executed in separate threads
            print("No jobs...")

    except (KeyboardInterrupt, SystemExit):
       scheduler.shutdown()
       print('Exit The Job!')