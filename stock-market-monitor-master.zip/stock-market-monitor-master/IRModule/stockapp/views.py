from rest_framework import status
from rest_framework import generics
from rest_framework import mixins
from rest_framework.views import APIView
from rest_framework.response import Response

from .models import Stock, DailyHomeItem, UserStocks

from .serializers import (StockSerializer, TickerSerializer,
                         TickerPriceSerializer, DailyHomeItemSerializer,
                         TickerTrendsSerializer, UserStocksSerializer)
from .services.extraction.stockextraction import StockExtractor

class StockAPIView(generics.GenericAPIView,
                   mixins.ListModelMixin,
                   mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.UpdateModelMixin,
                   mixins.DestroyModelMixin):

    serializer_class = StockSerializer
    queryset = Stock.objects.all()

    # lookup_filed = 'id'
    
    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]
    
    def list_symbols(self, request):
        symbols = Stock.objects.all().values("symbol")
        return Response(symbols)

    def list_histories(self, request):
        symbols = Stock.objects.all().values("symbol","history")
        return Response(symbols)
    
    def get(self, request, pk = None):
        if pk:
            """ GET: http://{{HOST_IP}}:{{PORT}}/stocks/<int:id> """
            # Get stock by id
            return self.retrieve(request)
        elif request.path.endswith('symbols'):
            """ GET:http://{{HOST_IP}}:{{PORT}}/stocks/symbols """
            # Get all symbols of all stocks stored in db
            return self.list_symbols(request)
        elif request.path.endswith('histories'):
            """ GET:http://{{HOST_IP}}:{{PORT}}/stocks/histories """
            # Get all histories of all stocks stored in db
            return self.list_histories(request)
        else:
            """ GET: http://{{HOST_IP}}:{{PORT}}/stocks """
            # Get all stocks 
            return self.list(request)

    """ POST: http://{{HOST_IP}}:{{PORT}}/stocks """
    def post(self, request):
        # Insert new stock
        return self.create(request)

    """ PUT: http://{{HOST_IP}}:{{PORT}}/stocks/<int:id> """
    def put(self, request, pk):
        # Update a stock information by id
        return self.update(request, pk)

    """ DELETE: http://{{HOST_IP}}:{{PORT}}/stocks/<int:id> """
    def delete(self, request, pk):
        # Delete stock by id
        return self.destroy(request, pk)

class SectorAPIView(APIView):

    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]

    """ GET: http://{{HOST_IP}}:{{PORT}}/sectors """
    def get(self, request):
        
        sectors = list(set([s.marketInfo['sector'] for s in Stock.objects.all() if s.marketInfo]))
        return Response(sectors, status = status.HTTP_200_OK)
 
# ============= HomeItems APIs =============

class DailyHomeItemAPIView(generics.GenericAPIView,
                   mixins.ListModelMixin,
                   mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.UpdateModelMixin,
                   mixins.DestroyModelMixin):

    serializer_class = DailyHomeItemSerializer 
    queryset = DailyHomeItem.objects.all()

    # lookup_filed = 'id'
    
    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]

    def retrieve_most_recent_item(self, request, *args, **kwargs):
        mri = DailyHomeItem.objects.latest('date')
        serializer = DailyHomeItemSerializer(mri, many=False)
        return Response(serializer.data)

    def get(self, request, pk = None):
        if pk:
            """ GET: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems<int:id> """
            return self.retrieve(request)
        elif request.path.endswith('today'):
            """ GET: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems/today """
            return self.retrieve_most_recent_item(request)
        else:
            """ GET: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems """
            return self.list(request)
    
    """ POST: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems """
    def post(self, request):
        return self.create(request)

    """ PUT: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems/<int:id> """
    def put(self, request, pk):
        return self.update(request, pk)

    """ DELETE: http://{{HOST_IP}}:{{PORT}}/stocks/homeitems/<int:id> """
    def delete(self, request, pk):
        return self.destroy(request, pk)

# ============= DP Communication Support APIs =============
class TickerProcessingAPIView(APIView):

    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]

    """ GET: http://{{HOST_IP}}:{{PORT}}/ticker/prices """
    def get(self, request, pk = None):
        if request.path.endswith('prices') and not pk:
            """
            API that returns a list whose entries are composed of:
            {symbol: "stockName", 
            "previousValue": "price", 
            "currentValue": "price", 
            "sector": "sectorName"}
            """
            symbolprices = [{'symbol': s.symbol, 
                                'previousValue': s.history[-2]['close'], 
                                'currentValue': s.history[-1]['close'],
                                'sector': s.marketInfo['sector']}
                            for s in Stock.objects.all() if s.history and len(s.history)>1]
            serializer = TickerPriceSerializer(symbolprices, many=True)
            return Response(serializer.data, status = status.HTTP_200_OK)
        # """ GET: http://{{HOST_IP}}:{{PORT}}/ticker/history/<str:symbol> """
        elif pk and request.path.find('history') != -1:
            historyStocks = Stock.objects.filter(symbol = pk).values('history')
            if historyStocks: return Response(historyStocks, status = status.HTTP_200_OK)
            else: return Response({"symbol":pk,"status":"Not Found"}, status = status.HTTP_404_NOT_FOUND)
        else: return Response(status = status.HTTP_400_BAD_REQUEST)

# ============= Extract new ticker API =============

class StockExtractorAPIView(APIView):

    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]
    
    """ POST: http://{{HOST_IP}}:{{PORT}}/ticker """
    def post(self, request):
        data = request.data
        querystock = Stock.objects.filter(symbol=data['symbol'])
        serializer = TickerSerializer(data = data)
        if serializer.is_valid():
            if not querystock:
                servres = StockExtractor(new=True).extractstock(data)
                if isinstance(servres,Stock):
                    return Response(data = {"request_status":"SUCCESS","ticker":servres.symbol}, 
                                    status = status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                servres = StockExtractor(new=False).extractstock(data)
                return Response(data = {"request_status":"UPDATED","message":"stock is up-to"}, 
                                status=status.HTTP_200_OK)
        else: return Response(data = {"request_status":"FAILED", "message":"a stock could not be extracted from the specified ticker"}, 
                              status = status.HTTP_500_INTERNAL_SERVER_ERROR)

class StockResolverAPIView(APIView):

    #authentication_classes = [TokenAuthentication]
    #permission_classes = [IsAuthenticatedOrReadOnly]

    def getmatches(self, reqsec, reqrf):
        stocks = DailyHomeItem.objects.latest('date').stocks
        return [{'symbol':s['symbol'],'riskFactor':reqrf} for s in stocks 
                if s['sector'] == reqsec and s['riskFactor'] == reqrf]

    def findwatchliststocks(self, symbol):
        stocks = DailyHomeItem.objects.latest('date').stocks
        reslist = [s for s in stocks if s['symbol'] == symbol]
        if reslist: return reslist[0]
    
    """ GET http://{{HOST_IP}}:{{PORT}}/watchlist/<str:id> """
    def get(self, request, pk):
        # get watchlist by username
        response = []
        queryset = UserStocks.objects.filter(username = pk).first()
        if queryset: 
            watchlist = queryset.watchlist
            if watchlist:
                # get stock info by symbol
                for entry in watchlist:
                    history = Stock.objects.filter(symbol=entry['symbol']).values('history').first()['history'][-30:-1]
                    selhistory = [{'date':history[i]['date'], 'price':history[i]['close']} for i in range(len(history))]
                    response.append({'general':self.findwatchliststocks(entry['symbol']),
                                     'history':selhistory})
                return Response(response, status = status.HTTP_200_OK)
            else: return Response(status = status.HTTP_204_NO_CONTENT)
        else: return Response(status = status.HTTP_204_NO_CONTENT)

    """ POST: http://{{HOST_IP}}:{{PORT}}/stocks/search """
    def post(self, request):
        userstocks = UserStocks()
        userstocks.username = request.data['username']
        watchlist = self.getmatches(request.data['sector'],request.data['riskFactor']) 
        if watchlist:
            userstocks.watchlist = watchlist
            queryset = UserStocks.objects.filter(username = request.data['username'])
            if not queryset: 
                userstocks.save()
                return Response(status=status.HTTP_201_CREATED)
            else: 
                UserStocks.objects.filter(username=request.data['username']).update(watchlist = watchlist)
                return Response(status=status.HTTP_200_OK)            
        else: return Response(status = status.HTTP_204_NO_CONTENT)
