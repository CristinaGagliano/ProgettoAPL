from djongo import models
from django import forms

# ==== Model Classes - db: stocks, collection: stockapp_stock ====

class RecommendationsItem(models.Model):
    date = models.CharField(max_length = 15, default="null", blank=True, null=True)
    firm = models.CharField(max_length = 200, default="null", blank=True, null=True)
    toGrade = models.CharField(max_length = 50, default="null", blank=True, null=True)
    fromGrade = models.CharField(max_length = 50, default="null", blank=True, null=True)
    action = models.CharField(max_length = 50, default="null", blank=True, null=True)

    class Meta:
        abstract = True

class RecommendationsForm(forms.ModelForm):

    class Meta:
        model = RecommendationsItem
        fields = ('date','firm','toGrade','fromGrade','action')

class HolderInfoItem(models.Model):
    holder = models.CharField(max_length = 200, default="null", blank=True, null=True)
    shares = models.BigIntegerField(default = 0, blank=True, null=True)
    dateReported = models.CharField(max_length = 15, default="null", blank=True, null=True)
    outPercentage = models.FloatField(default = 0.0, blank=True, null=True)
    value = models.BigIntegerField(default = 0, blank=True, null=True)

    class Meta:
        abstract = True

class HolderInfoForm(forms.ModelForm):

    class Meta:
        model = HolderInfoItem
        fields = ('holder','shares','dateReported','outPercentage','value')

class HoldersPercentages(models.Model):
    sharesInsiders = models.CharField(default = "0.0%", blank=True, null=True)
    sharesInstitutions = models.CharField(default = "0.0%", blank=True, null=True)
    floatInstitutions = models.CharField(default = "0.0%", blank=True, null=True)

    class Meta:
        abstract = True

class StockHolders(models.Model):
    numberInstitutions = models.IntegerField(default = 0, blank=True, null=True)
    percentages = models.EmbeddedField(model_container = HoldersPercentages,
                                       blank=True, null=True)
    holdersInfo = models.ArrayField(
        model_container = HolderInfoItem,
        model_form_class = HolderInfoForm,
        default=list,
        )

    class Meta:
        abstract = True

class HistoryItem(models.Model):
    date = models.CharField(max_length = 15, default="null")
    open = models.FloatField(default = 0.0)
    high = models.FloatField(default = 0.0)
    low = models.FloatField(default = 0.0)
    close = models.FloatField(default = 0.0)
    volume = models.BigIntegerField(default = 0)

    class Meta:
        abstract = True

class HistoryForm(forms.ModelForm):

    class Meta:
        model = HistoryItem
        fields = ('date','open','high','low','close','volume')

class MarketInfo(models.Model):
    market = models.CharField(max_length = 100, default="null", blank=True, null=True)
    sector = models.CharField(max_length = 100, default="null", blank=True, null=True)
    industry = models.CharField(max_length = 100, default="null", blank=True, null=True)

    class Meta:
        abstract = True

class GeneralStockInfo(models.Model):
    shortName = models.CharField(max_length = 100, default="null", blank=True, null=True)
    longName = models.CharField(max_length = 200, default="null", blank=True, null=True)
    longBusinessSummary = models.TextField(default="null", blank=True, null=True)
    currency = models.CharField(max_length = 5, default="null", blank=True, null=True)
    exchange = models.CharField(max_length = 5, default="null", blank=True, null=True)
    exchangeTimezoneName = models.CharField(max_length = 20, default="null", blank=True, null=True)
    website = models.CharField(max_length = 500, default="null", blank=True, null=True)
    phone = models.CharField(max_length = 20, default="null", blank=True, null=True)    
    fullTimeEmployees = models.IntegerField(default=1, blank=True, null=True)
    logo_url = models.CharField(max_length = 500, default="null", blank=True, null=True)
    zipCode = models.CharField(max_length = 20, default="null", blank=True, null=True)
    city = models.CharField(max_length = 100, default="null", blank=True, null=True)
    state = models.CharField(max_length = 100, default="null", blank=True, null=True)
    country = models.CharField(max_length = 100, default="null", blank=True, null=True)
    address = models.CharField(max_length = 500, default="null", blank=True, null=True)

    class Meta:
        abstract = True

class Stock(models.Model):
    symbol = models.CharField(max_length = 10)
    isin = models.CharField(max_length = 20, default="null", blank=True, null=True)
    source = models.CharField(max_length = 20, default="null", blank=True, null=True)
    general = models.EmbeddedField(model_container = GeneralStockInfo,
                                  blank= True, null=True)
    marketInfo = models.EmbeddedField(model_container = MarketInfo, 
                                      blank= True, null=True)
    history = models.ArrayField(
        model_container = HistoryItem,
        model_form_class = HistoryForm,
        default=list,
        )
    holders = models.EmbeddedField(model_container = StockHolders, 
                                   blank=True, null=True)
    recommendations = models.ArrayField(
        model_container = RecommendationsItem,
        model_form_class = RecommendationsForm,
        default=list, 
        )
    objects = models.DjongoManager()


# ==== Model Classes - db: stocks, collection: stockapp_dailyhomeitem ====

class DailySummary(models.Model):
    symbol = models.CharField(max_length = 10, default = "null", blank=True, null=True)
    currentValue = models.FloatField(default = 0.0)
    previousValue = models.FloatField(default = 0.0)
    sector = models.CharField(max_length = 50, default = "null", blank=True, null=True)
    percentage = models.FloatField(default = 0.0)
    riskFactor = models.IntegerField(default = 0)
    
    class Meta:
        abstract = True

class SectorDailySummary(models.Model):
    sectorName = models.CharField(max_length = 50, default = "null", blank=True, null=True)
    percentage = models.FloatField(default = 0.0, blank=True, null=True)

    class Meta:
        abstract = True

class DailySummaryForm(forms.ModelForm):

    class Meta:
        model = DailySummary
        fields = ('symbol','currentValue','previousValue','sector','percentage','riskFactor')

class DailyHomeItem(models.Model):
    date = models.DateTimeField(auto_now_add=True)
    bestStock = models.EmbeddedField(model_container = DailySummary,blank=True, null=True)
    worstStock = models.EmbeddedField(model_container = DailySummary,blank=True, null=True)
    bestSector = models.EmbeddedField(model_container = SectorDailySummary,blank=True, null=True)
    worstSector = models.EmbeddedField(model_container = SectorDailySummary,blank=True, null=True)
    stocks = models.ArrayField(
        model_container = DailySummary,
        model_form_class = DailySummaryForm,
        default=list, 
        )
    objects = models.DjongoManager()

# ==== Model Classes - db: stocks, collection: stockapp_userstocks ====

class SymbolField(models.Model):
    symbol = models.CharField(max_length = 10, default = "null", blank=True, null=True)
    riskFactor = models.IntegerField()
    class Meta:
        abstract = True

class SymbolFieldForm(forms.ModelForm):

    class Meta:
        model = SymbolField
        fields = ('symbol','riskFactor')

class UserStocks(models.Model):
    username = models.CharField(max_length = 50)
    watchlist = models.ArrayField(
        model_container = SymbolField,
        model_form_class = SymbolFieldForm,
        default=list, 
        )
    objects = models.DjongoManager()
