""" Python user-defined exceptions """

def print_exception_error(exception):
    print("Exception: {}".format(type(exception).__name__))
    print("Exception message: {}".format(exception))
    return 

class CustomException(Exception):
    """Base class for other exceptions"""
    pass

class EmptyConfigError(CustomException):
    """ Exception raised when no configuration information is read.

    Args:
        message -- explanation of the error
    """

    def __init__(self, message:str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message}'


class EmptySymbolTickersList(CustomException):
    """ Exception raised when symbol tickers list is empty.

    Args:
        message -- explanation of the error
    """

    def __init__(self, message:str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message}'

class UnknownDataSource(CustomException):
    """ Exception raised when the data source is unknown.

    Args:
        message -- explanation of the error
    """

    def __init__(self, message:str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message}'

class UnknownRequestType(CustomException):
    """ Exception raised when the request type to data source is unknown.

    Args:
        message -- explanation of the error
    """

    def __init__(self, message:str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message}'

class ResponseException(CustomException):
    """ Exception raised when it is not possible to 
        define an output from the extractor.

    Args:
        message -- explanation of the error
    """

    def __init__(self, message:str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message}'
