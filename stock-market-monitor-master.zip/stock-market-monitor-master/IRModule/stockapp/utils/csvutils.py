import csv

def readcsv(csvpath:str, fieldnames:list=[], newline:str='', delimiter:str=',', quotechar:str='"'):
    """
    Function that reads a csv file

    Args: 
        'csvpath':str, path of the csv file

        'fieldnames': list, list of values in csv header (default: [])

        'newline':str, newline character (default: "")
    
        'delimiter':str, A one-character string used to separate fields (default: ',')
    
        'quotechar':str, A one-character string used to quote fields that contain special characters,
            such as delimiter or quotechar, or that contain newline characters (default: '"')

    Return:
        List of rows read from the file csv
    """
    data = []
    if csvpath:
        try:
            with open(csvpath, 'r', newline=newline) as csvfile: 
                if not fieldnames: dataiter = csv.reader(csvfile, delimiter=delimiter, quotechar=quotechar)
                else:
                    dataiter = csv.DictReader(csvfile, fieldnames=fieldnames)
                    header = next(dataiter)
                for row in dataiter: data.append(row)
            csvfile.close()
            return data    
        except FileNotFoundError as ex:
            print('Error: %s not found'%csvpath)
    else:
        raise ValueError("Arg 'csvpath' must be a valid path expressed as a string")
