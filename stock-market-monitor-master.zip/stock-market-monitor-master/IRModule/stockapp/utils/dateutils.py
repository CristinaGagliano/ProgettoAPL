import typing
import datetime

from stockapp.exceptions.customexceptions import print_exception_error

def datetime_to_float(dt:datetime.datetime):
    """
    Utility function to convert a timestamp value (expressed in nanoseconds)
    into a DateTime type value according to an indicated format.

    Args:
        
        'dt':datetime, DateTime value
  
    Return: 
        A Float value expressed in nanoseconds that corresponds to the DateTime value
    """
    try:
        tsval = datetime.timestamp()
    except Exception as ex:
        print_exception_error(ex)

def timestamp_to_datetime(ts:float, datepattern:str="%Y-%m-%d %H:%M") -> datetime.datetime:
    """
    Utility function to convert a timestamp value (expressed in nanoseconds)
    into a DateTime type value according to an indicated format.

    Args:
        
        'ts':float, timestamp value 
        
        'datepattern':str, indicating in which format 
             you want to get the DateTime value
             - "%Y-%m-%d %H:%M"
             - "%Y/%m/%d %H:%M"
             it is possible to change the day, month and year at will.
  
    Return: 
        A DateTime value
        
    """
    try:
        dtval = datetime.datetime.utcfromtimestamp(ts).strftime(datepattern)
        return dtval
    except Exception as ex:
        print_exception_error(ex)
