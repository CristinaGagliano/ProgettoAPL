import typing 
import json

from stockapp.exceptions.customexceptions import print_exception_error

def getconfig(confpath) -> typing.Union[typing.Dict, None]:
    """
    Function that allows you to read the configuration file 
    and retrieve the information of interest.
    
    Args: 
    'confpath': str, path to config.json file.
    
    Return:
        A dictionary whose keys are the configurations of interest.
    """
    try:
        with open(confpath, 'r') as fconfig:
            config = json.load(fconfig)
        if config:
            return config
        else: 
            raise EmptyConfigError("'%s'file does not contain configuration information"%confpath)
    except FileNotFoundError as fnfex:
        print_exception_error(fnfex)
        return 
