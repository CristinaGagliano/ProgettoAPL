from rest_framework import serializers 
from .models import Stock, DailyHomeItem

""" Serializer for the entire Stock model """
class StockSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stock
        fields = '__all__'

#""" Serializer for the entire DailyHomeItem model """
#class DailyHomeItemSerializer(serializers.ModelSerializer):
#    class Meta:
#        model = DailyHomeItem
#        exclude = ['date']
    
class DailySummarySerializer(serializers.Serializer):
    symbol = serializers.CharField(min_length = 1, max_length = 6)
    currentValue = serializers.FloatField()
    previousValue = serializers.FloatField()
    sector = serializers.CharField(min_length = 1, max_length = 50)
    percentage = serializers.FloatField()
    riskFactor = serializers.IntegerField()

class SectorDailySummarySerializer(serializers.Serializer):
    sectorName = serializers.CharField(min_length = 1, max_length = 50)
    percentage = serializers.FloatField()

class DailyHomeItemSerializer(serializers.ModelSerializer):
   bestStock = DailySummarySerializer(many=False)
   worstStock = DailySummarySerializer(many=False)
   bestSector = SectorDailySummarySerializer(many=False)
   worstSector = SectorDailySummarySerializer(many=False)
   stocks = DailySummarySerializer(many=True)

   class Meta:
      model = DailyHomeItem
      fields = ('bestStock','worstStock','bestSector','worstSector','stocks')


""" 
Serializer for Ticker: {symbol + datasource}.

    Example:
    symbol: AAPL
    datasource: yahoofinance
"""

class TickerSerializer(serializers.Serializer):
    symbol = serializers.CharField(min_length = 1, max_length = 6, required = True)
    datasource = serializers.CharField(min_length = 1, max_length = 50, required = True)

""" 
Serializer for TickerPrice.

    Example:
    symbol: AAPL
    previousValue: 80.0
    currentValue: 85.0
    sector: Technology
"""
class TickerPriceSerializer(serializers.Serializer):
    symbol = serializers.CharField(min_length = 1, max_length = 6, required = True)
    previousValue = serializers.FloatField()
    currentValue = serializers.FloatField()
    sector = serializers.CharField()

class TickerTrendsSerializer(serializers.Serializer):
    symbols = serializers.ListField(child=serializers.CharField(min_length = 1, max_length = 6), required = True)
    fromDate = serializers.DateTimeField()
    toDate = serializers.DateTimeField()

#class UserPreferencesRequestSerializer(serializer.Serializer):
#    username = serializers.CharField(min_length = 1, required = True)
#    sector = serializers.CharField(min_length = 1, required = True)
#    riskFactor = serializers.IntegerField()

class UserStocksSerializer(serializers.Serializer):
    class Meta:
        model = Stock
        fields = '__all__'