from abc import ABC, abstractmethod
from datetime import datetime
import typing

class ExtractorStrategy(ABC):
    """
    Abstract base class that serves to define which 
    method the concrete classes will have to implement as a strategy
    """
    @abstractmethod
    def do_extraction(self, extractor): pass

class ExtractorContext():
    """ 
    Class for the Extraction Context 
    to store a reference to one of the strategies
    """
    def __init__(self, extstrategy:ExtractorStrategy) -> None:
        """Constructor of ExtractorContext

        :param extstrategy: an ExtractorStrategy object
        :type extstrategy: ExtractorStrategy
        """        
        self._extstrategy = extstrategy
    
    @property
    def extstrategy(self) -> ExtractorStrategy:
        return self._extstrategy

    @extstrategy.setter
    def extstrategy(self, extstrategy: ExtractorStrategy) -> None:
        self._extstrategy = extstrategy

    def extract(self, extractor) -> typing.Dict:
        """Method to perform the extraction 
        transparently to the algorithm

        :param extractor: an instance of a specialized extractor,
            for example an instance of YFExtractor
        :type extractor: BaseExtractor
        :return: a dictionary that contains the extracted data
        :rtype: Dict
        """
        return self.extstrategy.do_extraction(extractor)

class AllDataExtractor(ExtractorStrategy):
    """ 
    A concrete class to implement the "full" extraction logic
    """
    def do_extraction(self, extractor):
        """Perform an extraction strategy

        :param extractor: an instance of a specialized extractor,
            for example an instance of YFExtractor
        :type extractor: BaseExtractor
        :return: a dictionary that contains the extracted data
        :rtype: Dict
        """        
        return extractor.getalldata()

class DailyDataExtractor(ExtractorStrategy):
    """
    A concrete class to implement the "daily" extraction logic
    """
    def do_extraction(self, extractor):
        """Perform an extraction strategy

        :param extractor: an instance of a specialized extractor,
            for example an instance of YFExtractor
        :type extractor: BaseExtractor
        :return: a dictionary that contains the extracted data
        :rtype: Dict
        """        
        return extractor.getdailydata()

