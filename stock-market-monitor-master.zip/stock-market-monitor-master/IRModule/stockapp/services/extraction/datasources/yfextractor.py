"""
Classes for extracting and managing data offered by Yahoo Finance
"""

import json
import typing
import pandas as pd
import datetime as dt

import yfinance as yf

from stockapp.models import Stock
from stockapp.exceptions.customexceptions import UnknownRequestType, ResponseException, print_exception_error
from stockapp.services.extraction.extractorbase import BaseExtractor

class YFExtractor(BaseExtractor):
    """ 
    Concrete subclass of BaseExtractor that implements the 
    extraction logic for stocks from the Yahoo! Finance
    """    
    def __init__(self, symbol:str):
        """Constructor of YFExtractor

        :param symbol: a string representing a stock symbol,
            for example 'AAPL', 'MSFT', 'GOOGL'
        :type symbol: str
        """        
        self._symbol = symbol

    @property
    def symbol(self): 
        return self._symbol

    def _getgeneral(self, general:typing.Dict) -> typing.Dict:
        """Function that allows you to retrieve 
            the general information of a stock

        :param general: is a dictionary extracted from the dataframe 
            containing some general information about a stock
        :type general: typing.Dict
        :return: a dictionary with the fields of interest 
            retrieved from general
        :rtype: typing.Dict
        """        
        resdict = {}
        for f in ['shortName','longName','longBusinessSummary',
                'zip','city','state','country','address1',
                'currency','exchange','exchangeTimezoneName',
                'website','phone','fullTimeEmployees','logo_url']:
            if f in list(general.keys()):
                if f == 'zip': resdict["zipCode"] = general[f]
                elif f == 'address1': resdict["address"] = general[f]
                elif f == 'fullTimeEmployees': resdict[f] = int(general[f]) 
                else: resdict[f] = general[f]
            if 'fullTimeEmployees' not in list(general.keys()): 
                resdict['fullTimeEmployees'] = 1
        return resdict

    def _getmarket(self, market:typing.Dict) -> typing.Dict:
        """Function that allows you to retrieve information 
            on the market in which a stock is inserted

        :param market: is a dictionary extracted from the dataframe 
            containing a lot of market's info
        :type market: typing.Dict
        :return: a dictionary composed by 'market','sector'
             and 'industry' fields
        :rtype: typing.Dict
        """        
        resdict = {}
        for f in ['market','sector','industry']:
            if f in list(market.keys()):
                resdict[f] = market[f]
        return resdict

    def _gethistory(self, history:pd.DataFrame) -> typing.List:
        """Function that allows to insert in a list all the values ​​
            of the historical series on the trend of a given stock

        :param history: a dataframe with the market values ​​of the stock
        :type history: pd.DataFrame
        :return: a list of dictionaries whose entries are composed 
            of the prices 'high', 'low', 'open', 'close' 
            and also the date and volume of transactions
        :rtype: typing.List
        """        
        if not history.empty:
            history['Date'] = list(history.index)
            history['Date'] = history['Date'].dt.date.apply(str)
            history.reset_index(drop=True, inplace=True)
            history = history.drop(['Dividends','Stock Splits'], axis = 1).rename(columns=str.lower)
            return list(history.T.to_dict().values())
        else: return list()

    def _getdailyvalues(self, values:pd.DataFrame) -> typing.List:
        """Function that allows to insert in a list 
        daily values ​of a given stock

        :param values: a dataframe with the daily values ​​of the stock
        :type values: pd.DataFrame
        :return: a list of dictionaries whose entries are composed 
            of the prices 'high', 'low', 'open', 'close' 
            and also the date and volume of transactions
        :rtype: typing.List
        """
        if len(values) > 0:
            values['Date'] = list(values.index)
            values['Date'] = values['Date'].dt.date.apply(str)
            return list(values.drop(['Adj Close'],axis=1).rename(columns=str.lower).T.to_dict().values())
        else: return list()

    def _getholders(self, holders:pd.DataFrame, percentages:pd.DataFrame) -> typing.Dict:
        """Function that allows to obtain information on the stock's stackeholders

        :param holders: a dataframe that contains information about the stakeholders
        :type holders: pd.DataFrame
        :param percentages: a dataframe that contains information on the percentage 
            shares held by the various stakeholders
        :type percentages: pd.DataFrame
        :return: a dictionary that collect all information about stakeholders 
            by combining different information
        :rtype: typing.Dict
        """        
        resdict = {}
        percentages_list, holders_list = [], []
        if not holders.empty and not percentages.empty:
            percentages_list.append({'sharesInsiders':percentages.iloc[0,0]})
            percentages_list.append({'sharesInstitutions':percentages.iloc[1,0]})
            percentages_list.append({'floatInstitutions':percentages.iloc[2,0]})

            holders['Date Reported'] = holders['Date Reported'].dt.date.apply(str)
            for idx, row in holders.iterrows():
                holders_list.append({
                    'holder':row['Holder'],
                    'shares':row['Shares'],
                    'dateReported':row['Date Reported'],
                    'outPercentage':row['% Out'],
                    'value':row['Value']
                    })

            resdict['percentages'] = percentages_list
            resdict['holdersInfo'] = holders_list
            resdict['numberInstitutions'] = percentages.iloc[3,0]
        return resdict

    def _getrecommendations(self, recommendations:pd.DataFrame) -> typing.Dict:
        """Method that allows you to obtain some information 
            about the actions taken by various investors

        :param recommendations: a dataframe that reports a history of 
            actions taken by various investors over time
        :type recommendations: pd.DataFrame
        :return: a dictionary that allows you to obtain 
            the above information in the correct format
        :rtype: typing.Dict
        """        
        if not recommendations.empty:
            recommendations['Date'] = list(recommendations.index)
            recommendations['Date'] = recommendations['Date'].dt.date.apply(str)
            recommendations.reset_index(drop=True, inplace=True)

            newcols = {
                'Date':'date',
                'Firm':'firm',
                'To Grade':'toGrade',
                'From Grade':'fromGrade',
                'Action':'action'}

            recommendations = recommendations.rename(columns=newcols)
            return list(recommendations.T.to_dict().values())
        else: return list()

    def response(self, tickerdata:typing.Union[yf.Ticker, pd.DataFrame]) -> typing.Dict:
        """Method that allows you to obtain a dictionary 
            with the data extracted through Yahoo! Finance

        :param tickerdata: it can be either an instance of yf.Ticker or a pandas DataFrame
        :type tickerdata: typing.Union[yf.Ticker, pd.DataFrame]
        :raises ResponseException: Exception raised when tickerdata is not a DataFrame or yf instance
        :return: a dictionary with the data extracted through Yahoo! Finance
        :rtype: typing.Dict
        """        
        res = super(YFExtractor,YFExtractor).getresdict()
        
        if isinstance(tickerdata, yf.Ticker): 

            res['symbol'] = str(tickerdata.info['symbol'])
            res['isin'] = str(tickerdata.isin)
            res['general'] = dict(self._getgeneral(tickerdata.info))
            res['marketInfo'] = dict(self._getmarket(tickerdata.info))
            res['history'] = list(self._gethistory(tickerdata.history(period="60d")))
            res['holders'] = dict(self._getholders(tickerdata.institutional_holders,tickerdata.major_holders))
            res['recommendations'] = list(self._getrecommendations(tickerdata.recommendations))

        elif isinstance(tickerdata, pd.DataFrame):
            res['symbol'] = self.symbol
            res['history'] = self._getdailyvalues(tickerdata)

        else: raise ResponseException(
            "Error: An output could not be defined from the extractor: '%s'"%str(self.__class__))
        return res

    def datafromsource(self, reqtype:str) -> typing.Union[yf.Ticker, pd.DataFrame]:
        """Get the data from the source

        :param reqtype: string representing the type of API request ('all'|'daily')
        :type reqtype: str
        :raises UnknownRequestType: exception raised if the request type is not among those recognized
        :return: the result of the API to Yahoo! Finance
        :rtype: typing.Union[yf.Ticker, pd.DataFrame]
        """        
        try:
            if reqtype == 'all': return yf.Ticker(self.symbol)
            elif reqtype == 'daily': return yf.download(self.symbol, period='1d', interval='1d', progress=False)
            else: raise UnknownRequestType("Error: 'reqtype: %s' not valid"%reqtype)
        except Exception as ex:
            print_exception_error(ex)
            return 

    def getalldata(self) -> typing.Dict:
        """It performs the extraction in "full" mode

        :return: a dictionary with the data extracted through Yahoo! Finance
        :rtype: typing.Dict
        """        
        return self.response(self.datafromsource(reqtype = 'all'))
            
    def getdailydata(self) -> typing.Dict:
        """It performs the extraction in "daily" mode

        :return: a dictionary with the data extracted through Yahoo! Finance
        :rtype: typing.Dict
        """        
        return self.response(self.datafromsource(reqtype = 'daily'))
