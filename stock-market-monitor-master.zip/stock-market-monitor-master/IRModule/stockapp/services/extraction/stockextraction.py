import os
import json
import typing
import pathlib
import pandas as pd
import datetime as dt

from stockapp.models import Stock
from stockapp.utils.csvutils import readcsv
from stockapp.utils.confutils import getconfig
from stockapp.exceptions.customexceptions import *
from stockapp.services.extraction.datasources.yfextractor import YFExtractor
from stockapp.services.extraction.strategy import AllDataExtractor, DailyDataExtractor, ExtractorContext

PATH_CONFIG = os.path.join('stockapp','config.json')

class StockExtractor(object):
    """ 
    Class for extracting stocks from data sources
    """   
    def __init__(self, 
                new:bool = False,
                configpath:str = PATH_CONFIG):
        """Constructor of the StockExtractor class

        :param new: used to identify if it is a new stock, 
                        defaults to False
        :type new: boolean, optional
        :param configpath: string representing the path to 
                        the configuration file 'config.json, 
                        defaults to PATH_CONFIG
        :type configpath: str, optional
        """        
        self._configpath = configpath
        self._new = new

        self._tickers = self.tickers
        
    @property
    def configpath(self):
        return self._configpath 

    @property
    def new(self):
        return self._new

    @property
    def tickers(self):
        configdata = getconfig(self.configpath)
        datacsv = readcsv(configdata['tickers'], fieldnames=['SYMBOL','DATASOURCE'])
        if datacsv: return [{
            'symbol':tickeritem['SYMBOL'],
            'datasource':tickeritem['DATASOURCE']} 
            for tickeritem in datacsv if tickeritem]
        else: raise EmptySymbolTickersList('Symbol tickers list is empty')
    
    def _getstrategyextrator(self):
        """FactoryMethod as a object factory to instantiate 
        the extractor that implements the desired extraction strategy

        :return: a subclass of ExtractorStrategy
        :rtype: ExtractorStrategy
        """ 
        # if is a new stock or if sunday (day of week) then extract all data
        if self.new or dt.datetime.today().weekday == 6: return AllDataExtractor()
        else: return DailyDataExtractor()

    def _getextractorcontext(self) -> ExtractorContext:
        """Get Extractor Context

        :return: an ExtractorContext object
        :rtype: ExtractorContext
        """        
        return ExtractorContext(self._getstrategyextrator())

    def _getextractor(self, ticker:typing.Dict):
        """Factory Method as object factory to instantiate 
        the correct specialized extractor based on the data source 

        :param ticker: is a dictionary that 
            contains the ticker name and its datasource
        :type ticker: typing.Dict
        :raises UnknownDataSource: exception raised if the 
            data source passed to the function is not among those recognized
        :return: a YFExtractor object
        :rtype: YFExtractor
        """
        if ticker['datasource'] in getconfig(self.configpath)['datasources']:
            if ticker['datasource'] == 'yahoofinance': return YFExtractor(ticker['symbol'])
        else: raise UnknownDataSource("Arg 'datasource=%s' must be a valid data source"%ticker['datasource'])

    def extractstock(self, ticker:typing.Dict) -> Stock:
        """Function that implements the procedure for extracting a stock

        :param ticker: is a dictionary that 
            contains the ticker name and its datasource
        :type ticker: typing.Dict
        :return: an object of type Stock
        :rtype: Stock
        """        

        queryresult = Stock.objects.filter(symbol = ticker['symbol'])
        stock = Stock()
        stockdata = self._getextractorcontext().extract(self._getextractor(ticker))

        if queryresult:
            # update stock object with new data
            querystock = queryresult.first()
            if len(stockdata['history']) == 1:
                # daily update => stockdata with only new daily prices 
                if stockdata['history'][0]['date'] != querystock.history[-1]['date']:
                    history = querystock.history + stockdata['history']
                    queryresult.update(history = history)
                else: pass
            else:
                # full update => stockdata with all informations
                queryresult.update(general = stockdata['general'], 
                                   marketInfo = stockdata['marketInfo'], 
                                   history = stockdata['history'], 
                                   #holders = stockdata['holders'], 
                                   recommendations = stockdata['recommendations'])
            return queryresult.first()
        else:
            # create new stock object and save it 
            stock.symbol, stock.source = ticker['symbol'], ticker['datasource']
            stock.isin = stockdata['isin']
            stock.general = stockdata['general']
            stock.marketInfo = stockdata['marketInfo']
            stock.history = stockdata['history']
            #stock.holders = stockdata['holders']
            stock.recommendations = stockdata['recommendations']
        stock.save()
        return stock
