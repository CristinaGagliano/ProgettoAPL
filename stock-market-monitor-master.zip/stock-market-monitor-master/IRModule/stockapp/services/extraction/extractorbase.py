from abc import ABC, abstractmethod
import typing
import pandas as pd

import yfinance as yf

class BaseExtractor:
    """
    Basic extractor that serves to define a standard model 
    for each specialized extractor
    """    
    @abstractmethod
    def datafromsource(self, reqtype:str) -> typing.Union[yf.Ticker, pd.DataFrame]: pass

    @abstractmethod
    def getalldata(self) -> typing.Dict: pass

    @abstractmethod
    def getdailydata(self) -> typing.Dict: pass

    @staticmethod
    def getresdict() -> typing.Dict:
        """Static method to define what the extraction 
        output should be for a generic extractor

        :return: a dictionary
        :rtype: typing.Dict
        """        
        return {'symbol':str(),'isin':str(),'general':dict(),'marketInfo':dict(),
               'history':list(),'holders':dict(),'recommendations':list()}
