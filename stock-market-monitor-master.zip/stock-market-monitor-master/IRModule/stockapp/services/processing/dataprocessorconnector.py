import os
import typing 
import subprocess

def analyze_trends(host:str = "127.0.0.1", port:int = 8000) -> typing.Dict:
    """Function that allows to execute through the script on the DataProcessor module for data processing
    :param host: ip address of host  
    :type host: str
    :param port: port number  
    :type port: int
    :return: the values on standard output
    :rtype: typing.Dict
    """    
    res = subprocess.run(["C:/Program Files (x86)/R_SERVER/bin/Rscript.exe", # R interpreter path 
                 '../DataProcessor/R/tickerProcessing.R', # R script 
                 "--pathGetPrices", "http://"+host+":"+str(port)+"/ticker/prices", # GET path to retrieve price information 
                 "--pathGetHistories", "http://"+host+":"+str(port)+"/ticker/history", # GET path to retrieve the history's stock
                 "--pathPostHomeitem", "http://"+host+":"+str(port)+"/stocks/homeitems"], # POST path to send the processing results
                stdout=subprocess.PIPE)
    stdres = res.stdout.decode('utf-8')
    return stdres