from django.apps import AppConfig


class StockappConfig(AppConfig):
    name = 'stockapp'
