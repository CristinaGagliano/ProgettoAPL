.. IRModule documentation master file, created by
   sphinx-quickstart on Fri Feb  5 23:05:06 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

IRModule v.1.0.0 User Documentation
====================================
IRModule
------------------------------------
settings.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: IRModule.settings
   :members:

asgi.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: IRModule.asgi
   :members:

wgsi.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: IRModule.wsgi
   :members:
   
StockApp
------------------------------------
models.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.models
   :members:

services.extraction.stockextraction.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. autoclass:: stockapp.services.extraction.stockextraction::StockExtractor
   :members:
   :private-members:

services.extraction.strategy.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. autoclass:: stockapp.services.extraction.strategy::ExtractorStrategy
   :members:
   :private-members:

.. autoclass:: stockapp.services.extraction.strategy::ExtractorContext
   :members:
   :private-members:

.. autoclass:: stockapp.services.extraction.strategy::AllDataExtractor
   :members:
   :private-members:

.. autoclass:: stockapp.services.extraction.strategy::DailyDataExtractor
   :members:
   :private-members:

services.extraction.extractorbase.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. autoclass:: stockapp.services.extraction.extractorbase::BaseExtractor
   :members:
   :private-members:

services.extraction.datasources.yfextractor.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. autoclass:: stockapp.services.extraction.datasources.yfextractor::YFExtractor
   :members:
   :private-members:

services.processing.dataprocessorconnector.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.services.processing.dataprocessorconnector
   :members:

Utility Functions
------------------------------------
utils.confutils.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.utils.confutils
   :members:

utils.csvutils.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.utils.csvutils
   :members:

utils.dateutils.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.utils.dateutils
   :members:

Exceptions
------------------------------------
exceptions.customexceptions.py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. automodule:: stockapp.exceptions.customexceptions
   :members:


.. toctree::
   :maxdepth: 10
   :caption: Contents:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
